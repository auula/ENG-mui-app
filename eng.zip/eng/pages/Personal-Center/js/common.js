
var url = "http://47.107.55.225/index";
var getUrl = "http://47.107.55.225/engineer";


//获取地址参数
//function GetQueryString(name){
//  var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
//  var r = window.location.search.substr(1).match(reg);
//  if(r!=null){
//   	return unescape(r[2]);
//   	return null;
//  }
//}
//var user_id = user_id;   //用户id
//var portData = portData;  //账号密码
////判断是否为空值
//if(GetQueryString("user_id") !=null && GetQueryString("user_id").toString().length>1){
// user_id = GetQueryString("user_id");
//}
//if(GetQueryString("portData") !=null && GetQueryString("portData").toString().length>1){
// portData = GetQueryString("portData");
//}


//function getUpload(obj){
//  //ajax请求数据
//  method:function(url,data,method,func){
//      $.ajax({
//          url: url,
//          dataType : "jsonp",
//          data: data,
//          method: post,
//          success: function (data) {
//            	console.log(data);
//				func(data);
//          },
//          error: function (data) {
//              console.log(data);
//				func(data);
//          }
//      });
//  }
//}