$(document).ready(function(){
    var card_num = card_num;
    var card_id = card_id;
    var user_id = user_id;
    $.ajax({
        type: "post",
        url: "http://47.107.55.225/index/Index/cardList",
        data: { 
            card_num: card_num,
            card_id: card_id,
            user_id: "22"
        },
        dataType: "json",        //返回数据形式为json
        success: function (e) {
            console.log(e);
            data = e.data;
            var str = "";
            console.log(11);
            for (var i = 0; i < data.length; i++) {
                str += '<div class="card" id="first_btn">'
                        +'<div class="card_number" id="user_id">'
//                      +'<img class="img-responsive" src="images/gonghan.png">'
                        +'<div class="txt0"><span>中国工商银行</span><br>'+ data[i].card_num +'</div>'
                        +'</div>'
//                      +'<div class="youxiaoqi">有效期：08/30</div>'
                        +'</div>';
            }
            console.log(str);
            $("#t_body").append(str);
        },
        error: function (errorMsg) {

        }
    });


}) ;