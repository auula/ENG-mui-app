mui.init();
mui.plusReady(function(){
	var user_id=plus.storage.getItem("user_id");
	var portData=plus.storage.getItem('portData');
	var user_type=plus.storage.getItem('user_type');
	if(user_id&&portData&&user_type=='2'){
		mui.openWindow({  
		    url: "../menu/main.html", 
		    id: "main", 
		    show: {  
		        autoShow: true, //页面loaded事件发生后自动显示，默认为true  
		        aniShow: "fade-in", //页面显示动画，默认为”slide-in-right“；  
		        duration: "100" //页面动画持续时间，Android平台默认100毫秒，iOS平台默认200毫秒；  
		    },  
		    waiting: {  
		        autoShow: true, //自动显示等待框，默认为true  
		        title: '正在加载...', //等待对话框上显示的提示内容  
		        options: {   
		            width: "100px", //等待框背景区域宽度，默认根据内容自动计算合适宽度  
		            height: "100px", //等待框背景区域高度，默认根据内容自动计算合适高度  
		        }     
		    }  
		})  
	};
	mui(".login-content").on("tap",".zhanghao-login-qc",function(){
		document.getElementById("phone").value="";
		document.getElementById("rphone").value="";
	});
	var second=60;
    function settime() {
        if (second == 0) {
			document.getElementById("getCode").classList.remove("yzm-btn-active");
			document.getElementById("getCode").innerHTML="获取验证码";
            second = 60;
            return;
        } else {
			document.getElementById("getCode").classList.add("yzm-btn-active");
			document.getElementById("getCode").innerHTML=second+"s";
            second--;
        }
        setTimeout(function() {
            settime()
        },1000)
    }; 
	function login(){
		var phone=document.getElementById("phone").value;
		var password=document.getElementById("password").value;
		
		if(phone == "") {
			mui.toast("请输入用户名");
			return false;
		}else if(password == "") {
			mui.toast("请输入密码");   
			return false;  
		}
		mui.ajax({
			type: "POST",
			url: url+"/Login/login",
			data:{'phone': phone,'password': password,'usertype': 2},
			dataType: 'json',
			success: function(e) {
				if(e.code == 1) {
					mui.toast(e.msg);
					void plus.storage.setItem("user_id",e.data.user_id.toString());
					void plus.storage.setItem('user_username',e.data.user_username);
					void plus.storage.setItem('user_realname',e.data.user_realname);
					void plus.storage.setItem('portData', e.data.portData);
					void plus.storage.setItem('user_images', e.data.user_images);
					void plus.storage.setItem('user_type', e.data.user_type.toString());
					if(e.data.user_info_status==0){
						setTimeout(function(){
							window.location.href="fill-information.html";
						},1000);
					}else if(e.data.user_info_status==3){
						setTimeout(function(){
							window.location.href="fill-information.html";
						},1000);
					}else{
						setTimeout(function(){
							window.location.href="../menu/main.html";    			
						},1000);
					}
				}else{
					mui.toast(e.msg);
				}
			}
		})
	};
	function register(){
		var user_cid=plus.push.getClientInfo().clientid;
		var rphone=document.getElementById("rphone").value.trim();
		var rpassword=document.getElementById("rpassword").value.trim();
		var code=document.getElementById("rpcode").value.trim();
		if(rphone==''){
			mui.toast("请填写手机号码");
			return false;
		}
		if(code==''){
			mui.toast("请填写验证码");
			return false;
		}
		if(rpassword==''){
			mui.toast("请填写密码");
			return false;
		}
		if(rpassword.length<6){
			mui.toast('密码不能少于6位');
			return false;
		}
		var validatePass=/^(?=.*[a-z])(?=.*\d)[a-z\d]{6,20}$/;
	 	if(!(validatePass.test(rpassword))){
	 		mui.toast('密码必须包含字母和数字');
			return false;
	 	}
		mui.ajax({
			url: url+"/Login/register", 
			type: "post",
			dataType: "json",
			data: {'phone': rphone,'code':code ,'usertype':2,'password': rpassword,'user_cid':user_cid},
			success:function(e){
				if(e.code == 1){
					mui.toast(e.msg);
					void plus.storage.setItem("user_id",e.data.user_id.toString());
					void plus.storage.setItem('user_username',e.data.user_username);
					void plus.storage.setItem('portData', e.data.portData);
					void plus.storage.setItem('user_realname',e.data.user_realname);
					void plus.storage.setItem('user_images', e.data.user_images);
					void plus.storage.setItem('user_type', e.data.user_type.toString());
					if(e.data.user_info_status==2){
						setTimeout(function(){
							window.location.href="../menu/main.html";    			
						},1000);
					}else{
						setTimeout(function(){
							window.location.href="fill-information.html";
						},1000);
					}
				}else if(e.code==2){
					mui.toast(e.msg); 
					return false;
				}else if(e.code==3){
					mui.toast(e.msg);  
					return false;
				}else{
					mui.toast(e.msg);  
					return false;
				}
			}
		});
	};
	mui(".yanzheng-input").on('tap','#getCode',function(){
		document.activeElement.blur();
		if(second!=60&&second>0){
			mui.toast('60秒后可重新发送');
			return false;
		}
		var rphone=document.getElementById("rphone").value.trim();
		var isMobile=/^1[0-9]\d{9}/;
	 	if(rphone==''){
	 		mui.toast('请输入手机号码');
	 		return false;
	 	}else if(!(isMobile.test(rphone))) {
			mui.toast('请输入有效的手机号码');
			return false;
		}
		mui.ajax({
			url: url+"/Login/getCode",
			type: "POST",
			data: {'phone': rphone},
			dataType: "json",
			success: function(e) {
				if(e.code==1){
					mui.toast(e.msg);
					settime();
				}else{
					mui.toast("验证码发送失败");
				}
			}
		})
	});
	document.addEventListener("keypress",function(event){
		if(event.keyCode == "13"){
			if(document.getElementById("item1").className=="mui-control-content mui-active"){
				login();
			}else if(document.getElementById("item2").className=="mui-control-content mui-active"){
				register();
			}
		}
	});
	mui(".login-btn").on('tap','#login_btn',function(){
		document.activeElement.blur();
		login();
	});
	mui(".login-btn").on('tap','#sends',function(){
		document.activeElement.blur();
		register();
	});
	mui(document).on("tap","#forgetPass",function(){
		console.log("aaaa");
		mui.openWindow({  
		    url: "recover-pw.html",
		    id: "recover-pw",
		    createNew:true,
		    show: {  
		        autoShow: true, //页面loaded事件发生后自动显示，默认为true  
		        aniShow: "fade-in", //页面显示动画，默认为”slide-in-right“；  
		        duration: "100" //页面动画持续时间，Android平台默认100毫秒，iOS平台默认200毫秒；  
		    },  
		    waiting: {  
		        autoShow: true, //自动显示等待框，默认为true  
		        title: '正在加载...', //等待对话框上显示的提示内容  
		        options: {   
		            width: "100px", //等待框背景区域宽度，默认根据内容自动计算合适宽度  
		            height: "100px", //等待框背景区域高度，默认根据内容自动计算合适高度  
		        }     
		    }  
		})  
	})
	mui(document).on("tap","#admin",function(){
		mui.openWindow({  
		    url: "http://47.107.55.225/backend/index/index", 
		    
		    show: {  
		        autoShow: true, //页面loaded事件发生后自动显示，默认为true  
		        aniShow: "fade-in", //页面显示动画，默认为”slide-in-right“；  
		        duration: "100" //页面动画持续时间，Android平台默认100毫秒，iOS平台默认200毫秒；  
		    },  
		    waiting: {  
		        autoShow: true, //自动显示等待框，默认为true  
		        title: '正在加载...', //等待对话框上显示的提示内容  
		        options: {   
		            width: "100px", //等待框背景区域宽度，默认根据内容自动计算合适宽度  
		            height: "100px", //等待框背景区域高度，默认根据内容自动计算合适高度  
		        }     
		    }  
		})  
	})
	var first = null;  
        mui.back=function(){
        	if(!first){  
            	first = new Date().getTime();  
            	mui.toast('再按一次退出应用');  
            	setTimeout(function(){  
                	first = null;  
            	},2000);  
        	}else {  
	            if(new Date().getTime() - first < 2000){  
	                plus.runtime.quit();  
	            }  
        	}  
       }
})

